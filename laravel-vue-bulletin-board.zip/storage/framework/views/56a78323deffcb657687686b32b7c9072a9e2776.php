<input type="hidden" id="serverImage" value="<?php echo e($image); ?>">
<div class="upload-image container">
    <div class="panel">
        <div class="button_outer">
            <div class="btn_upload btn btn-outline-primary">
                <input type="file" id="upload_file" name="image" 
                    accept="image/*" onmouseover="this.title='';">
                Upload image
            </div>
            <div class="processing_bar"></div>
            <div class="success_box"></div>
        </div>
    </div>
    <div class="error_msg"></div>
    <div class="uploaded_file_view" id="uploaded_view">
        <span class="file_remove">X</span>
    </div>
</div>
<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/components/widgets/upload-image.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/components/widgets/upload_image.blade.php ENDPATH**/ ?>