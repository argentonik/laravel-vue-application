<?php $__env->startSection('title', 'Bulletin view'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bulletins-show col-md-6 offset-md-3">
        <div class="card" id="show-card">
            <img src="<?php echo e(Storage::url($bulletin->image)); ?>" class="card-img-top" alt="Image">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($bulletin->title); ?></h5>
                <p class="card-text"><?php echo e($bulletin->description); ?></p>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Phone: <?php echo e($bulletin->phone); ?></li>
                <li class="list-group-item">Country: <?php echo e($bulletin->country); ?></li>
                <li class="list-group-item">Email: <?php echo e($bulletin->email); ?></li>
            </ul>
            <div class="card-body">
                <?php $__env->startComponent('components.widgets.map'); ?>
                    <?php $__env->slot('latitude'); ?>
                        <?php echo e($latitude); ?>

                    <?php $__env->endSlot(); ?>
                    <?php $__env->slot('longitude'); ?>
                        <?php echo e($longitude); ?>

                    <?php $__env->endSlot(); ?>
                <?php if (isset($__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6)): ?>
<?php $component = $__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6; ?>
<?php unset($__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                <hr>
                <span class="create-date"><?php echo e($bulletin->date); ?></span>
                <?php if($editable): ?>
                    <a href="<?php echo e(route('bulletins/edit', $bulletin->id)); ?>" class="btn btn-outline-primary">Edit</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/bulletins/show.blade.php ENDPATH**/ ?>