<div class="form-group">
    <input type="hidden" id="latitude" name="latitude" value="<?php echo e(old('latitude') ? old('latitude') : $latitude); ?>">
</div>
<div class="form-group">
    <input type="hidden" id="longitude" name="longitude" value="<?php echo e(old('longitude') ? old('longitude') : $longitude); ?>">
</div>
<div class="google-map" id="map"></div>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/components/widgets/map.js')); ?>"></script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCImHowMV88Ou6POksj4J5s0zrp2lu_K5M&callback=initMap">
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/components/widgets/map.blade.php ENDPATH**/ ?>