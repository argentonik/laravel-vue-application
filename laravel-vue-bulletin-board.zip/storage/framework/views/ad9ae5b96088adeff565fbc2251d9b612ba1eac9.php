<?php $__env->startSection('title', 'Bulletins'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bulletins-index col-md-6 offset-md-3">
        <?php if(!$bulletins->total()): ?>
            <div class="alert alert-primary" role="alert">
                No items...
            </div>
        <?php endif; ?>

        <?php $__currentLoopData = $bulletins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulletin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="<?php echo e(Storage::url($bulletin->image)); ?>" class="card-img" alt="Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <a href="<?php echo e(route('bulletins/show', $bulletin->id)); ?>"><h5 class="card-title"><?php echo e($bulletin->title); ?></h5></a>
                            <p class="card-text"><?php echo e($bulletin->description); ?></p>
                            <p class="card-text"><small class="text-muted"><?php echo e($bulletin->date); ?></small></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="row">
            <div class="col-12 text-center">
                <?php echo e($bulletins->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/bulletins/index.blade.php ENDPATH**/ ?>