<?php $__env->startSection('navigation'); ?>
    <div class="site-navigation menu d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 border-bottom box-shadow">
        <h5 class="my-0 mr-md-auto font-weight-normal"><a href="/">Bulletin board</a></h5>
        <p></p>
        <?php if(auth()->guard()->check()): ?>
            <a class="btn btn-outline-primary" href="<?php echo e(route('bulletins/create')); ?>" style="margin-right: 20px;">Add new +</a>
            <div class="dropdown">
                <button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton" 
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-user"></i><?php echo e(Auth::user()->name); ?>

                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="javascript:void" onclick="$('#logout-form').submit();">Logout</a>
                </div>
            </div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <a class="btn btn-outline-primary" href="<?php echo e(route('login')); ?>" style="margin-right: 20px;">Login</a>
            <a class="btn btn-outline-primary" href="<?php echo e(route('register')); ?>">Register</a>
        <?php endif; ?>
    </div>
<?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/common/navigation.blade.php ENDPATH**/ ?>