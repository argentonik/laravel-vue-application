<?php $__env->startSection('title', 'Bulletin create'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bulletins-create col-md-6 offset-md-3">
        <div class="card card-outline-secondary" id="create-card">
            <div class="card-header">
                <h3 class="mb-0">
                    <?php if(isset($create)): ?>
                        Create
                    <?php else: ?>
                        Edit
                    <?php endif; ?>
                </h3>
            </div>
            <div class="card-body">
                <?php if(isset($bulletin->id)): ?> 
                    <?php echo e(Form::open(['route' => array('bulletins/update', $bulletin->id), 
                                   'method' => 'post', 
                                   'files' => true])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['route' => 'bulletins/store', 
                                   'method' => 'post', 
                                   'files' => true])); ?>

                <?php endif; ?>
                    <?php echo e(Form::token()); ?>


                    <?php $__env->startComponent('components.widgets.upload_image'); ?>
                        <?php $__env->slot('image'); ?>
                            <?php echo e($bulletin->image); ?>

                        <?php $__env->endSlot(); ?>
                    <?php if (isset($__componentOriginal3fb73a3cc6dc8bb1fe63f595903eab918a3d7e16)): ?>
<?php $component = $__componentOriginal3fb73a3cc6dc8bb1fe63f595903eab918a3d7e16; ?>
<?php unset($__componentOriginal3fb73a3cc6dc8bb1fe63f595903eab918a3d7e16); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                    <div class="form-group required">
                        <?php echo e(Form::label('title', 'Title')); ?>

                        <?php echo e(Form::text('title', 
                                 old('title', $bulletin->title), [
                                     'class' => 'form-control', 
                                     'required' => 'required',
                                     'placeholder' => 'Title'])); ?>

                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group required">
                        <?php echo e(Form::label('description', 'Description')); ?>

                        <?php echo e(Form::textarea('description', 
                                 old('description', $bulletin->description), [
                                     'class' => 'form-control', 
                                     'required' => 'required',
                                     'placeholder' => 'Description',
                                     'rows' => 5])); ?>

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                  
                    </div>

                    <div class="form-group required">
                        <?php echo e(Form::label('phone', 'Phone')); ?>

                        <?php echo e(Form::text('phone', 
                                 old('phone', $bulletin->phone), [
                                     'class' => 'form-control', 
                                     'required' => 'required',
                                     'placeholder' => '+1 (___) ___-____',
                                     'data-mask' => '+1 (000) 000-0000'])); ?>

                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group required">
                        <?php echo e(Form::label('country', 'Country')); ?>

                        <?php echo e(Form::text('country', 
                                 old('country', $bulletin->country), [
                                     'class' => 'form-control', 
                                     'required' => 'required',
                                     'placeholder' => 'Country'])); ?>

                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group required">
                        <?php echo e(Form::label('email', 'Email')); ?>

                        <?php echo e(Form::email('email', 
                                 old('email', $bulletin->email), [
                                     'class' => 'form-control', 
                                     'required' => 'required',
                                     'placeholder' => 'Email'])); ?>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group required">
                        <?php echo e(Form::label('datepicker', 'Valid to')); ?>

                        <?php echo e(Form::text('valid_to', 
                                 old('valid_to', $bulletin['valid_to']), [
                                     'id' => 'datepicker',
                                     'class' => 'form-control datepicker', 
                                     'required' => 'required',
                                     'placeholder' => 'Date'])); ?>

                        <?php $__errorArgs = ['valid_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($errors->first('valid_to')); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <p>Your location:</p>
                    <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($errors->first('latitude')); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($errors->first('longitude')); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php $__env->startComponent('components.widgets.map'); ?>
                        <?php $__env->slot('latitude'); ?>
                            <?php echo e(optional($bulletin->coordinate)->latitude); ?>

                        <?php $__env->endSlot(); ?>
                        <?php $__env->slot('longitude'); ?>
                            <?php echo e(optional($bulletin->coordinate)->longitude); ?>

                        <?php $__env->endSlot(); ?>
                    <?php if (isset($__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6)): ?>
<?php $component = $__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6; ?>
<?php unset($__componentOriginale5371c09d0dfb52a1d154b5a1ab17b25b75968a6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-lg float-right">
                            Save
                        </button>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(asset('js/components/widgets/jquery.mask.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/components/widgets/datepickerConfigs.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\laravel-vue-bulletin-board\laravel-vue-bulletin-board\resources\views/bulletins/create.blade.php ENDPATH**/ ?>