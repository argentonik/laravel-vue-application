Инициализация базы данных:
`php artisan migrate`

Заполнение базы тестовыми данными (редактирование доступно с учетной записи 
admin@admin password):
`php artisan db:seed`
