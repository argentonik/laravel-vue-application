<template>
    <v-layout justify-center>
        <h1>Page not found :(</h1>
    </v-layout>
</template>

<style scoped>
    h1 {
        color: gray;
    }
</style>